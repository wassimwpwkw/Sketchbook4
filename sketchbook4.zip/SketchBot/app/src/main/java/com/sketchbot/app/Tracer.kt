package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.net.Uri

object Tracer {

    class Result(val strokes: List<List<PointF>>, val w: Int, val h: Int, val preview: Bitmap)

    // ---------- تحميل الصورة + قص الهوامش البيضاء ----------
    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (Math.max(o.outWidth, o.outHeight) / s > 2600) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val full = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, o2)
        } ?: return null
        val bmp = cropToContent(full)
        val k = maxSide.toFloat() / Math.max(bmp.width, bmp.height)
        return if (k < 1f) Bitmap.createScaledBitmap(
            bmp,
            Math.max(1, (bmp.width * k).toInt()),
            Math.max(1, (bmp.height * k).toInt()),
            true
        ) else bmp
    }

    private fun cropToContent(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                if (Color.alpha(c) < 128) continue
                if (Color.red(c) < 240 || Color.green(c) < 240 || Color.blue(c) < 240) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return src
        val pad = 16
        val x0 = Math.max(0, minX - pad)
        val y0 = Math.max(0, minY - pad)
        val x1 = Math.min(w - 1, maxX + pad)
        val y1 = Math.min(h - 1, maxY + pad)
        return Bitmap.createBitmap(src, x0, y0, x1 - x0 + 1, y1 - y0 + 1)
    }

    private fun grad(c: IntArray, i: Int, w: Int): Int {
        val gx = -c[i - w - 1] + c[i - w + 1] - 2 * c[i - 1] + 2 * c[i + 1] - c[i + w - 1] + c[i + w + 1]
        val gy = -c[i - w - 1] - 2 * c[i - w] - c[i - w + 1] + c[i + w - 1] + 2 * c[i + w] + c[i + w + 1]
        return Math.abs(gx) + Math.abs(gy)
    }

    // تآكل/تمدد سريع بمربع نصف قطره r
    private fun morph(src: BooleanArray, w: Int, h: Int, r: Int, erode: Boolean): BooleanArray {
        val tmp = BooleanArray(w * h)
        val out = BooleanArray(w * h)
        val pre = IntArray(Math.max(w, h) + 1)
        val full = 2 * r + 1
        for (y in 0 until h) {
            pre[0] = 0
            for (x in 0 until w) pre[x + 1] = pre[x] + (if (src[y * w + x]) 1 else 0)
            for (x in 0 until w) {
                val a = Math.max(0, x - r)
                val b = Math.min(w - 1, x + r)
                val c = pre[b + 1] - pre[a]
                tmp[y * w + x] = if (erode) c == full else c > 0
            }
        }
        for (x in 0 until w) {
            pre[0] = 0
            for (y in 0 until h) pre[y + 1] = pre[y] + (if (tmp[y * w + x]) 1 else 0)
            for (y in 0 until h) {
                val a = Math.max(0, y - r)
                val b = Math.min(h - 1, y + r)
                val c = pre[b + 1] - pre[a]
                out[y * w + x] = if (erode) c == full else c > 0
            }
        }
        return out
    }

    /**
     * threshold: حد السواد للخطوط الداكنة
     * detail: 0 = الخطوط الداكنة فقط، وكلما زاد ظهرت حدود الألوان والتفاصيل
     * fillGap: المسافة بين خطوط تعبئة المساحات الداكنة الكبيرة (مثل العيون)
     */
    fun process(src: Bitmap, threshold: Int, detail: Int, fillGap: Int): Result {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val rr = IntArray(w * h)
        val gg = IntArray(w * h)
        val bb = IntArray(w * h)
        val lum = IntArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            if (Color.alpha(c) < 128) {
                rr[i] = 255; gg[i] = 255; bb[i] = 255; lum[i] = 255
            } else {
                rr[i] = Color.red(c); gg[i] = Color.green(c); bb[i] = Color.blue(c)
                lum[i] = (0.299 * rr[i] + 0.587 * gg[i] + 0.114 * bb[i]).toInt()
            }
        }

        val dark = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            dark[i] = lum[i] < threshold
        }

        // المساحات الداكنة السميكة (العيون مثلاً): تُعبّأ بخطوط متوازية بدل الهيكل
        val rad0 = Math.max(5, Math.max(w, h) / 130)
        val thick = morph(dark, w, h, rad0, true)
        val opened = morph(thick, w, h, rad0, false)
        val region = BooleanArray(w * h)
        for (i in region.indices) region[i] = opened[i] && dark[i]

        val mask = BooleanArray(w * h)
        for (i in mask.indices) mask[i] = dark[i] && !region[i]

        if (detail > 0) {
            val t = Math.max(15, 115 - detail)
            val rad = 4
            for (y in rad until h - rad) {
                for (x in rad until w - rad) {
                    val i = y * w + x
                    if (dark[i]) continue
                    val m = Math.max(grad(rr, i, w), Math.max(grad(gg, i, w), grad(bb, i, w))) / 4
                    if (m <= t) continue
                    var near = false
                    var yy = -rad
                    while (yy <= rad && !near) {
                        var xx = -rad
                        while (xx <= rad) {
                            if (dark[i + yy * w + xx]) { near = true; break }
                            xx++
                        }
                        yy++
                    }
                    if (!near) mask[i] = true
                }
            }
        }

        thin(mask, w, h)
        val strokes = ArrayList<List<PointF>>()
        strokes.addAll(trace(mask, w, h))
        strokes.addAll(hatch(region, w, h, Math.max(2, fillGap)))

        // معاينة تُرسم من الخطوط نفسها
        val prev = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(prev)
        cv.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        for (st in strokes) {
            val p = Path()
            p.moveTo(st[0].x, st[0].y)
            for (k in 1 until st.size) p.lineTo(st[k].x, st[k].y)
            cv.drawPath(p, paint)
        }
        return Result(strokes, w, h, prev)
    }

    // تعبئة بخطوط أفقية متوازية، بالتناوب في الاتجاه
    private fun hatch(region: BooleanArray, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val out = ArrayList<List<PointF>>()
        var rowIdx = 0
        var y = gap / 2 + 1
        while (y < h - 1) {
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (region[y * w + x]) {
                    val s = x
                    while (x < w && region[y * w + x]) x++
                    if (x - s >= 3) runs.add(intArrayOf(s, x - 1))
                } else {
                    x++
                }
            }
            if (rowIdx % 2 == 1) runs.reverse()
            for (r in runs) {
                val a = PointF(r[0] + 0.5f, y + 0.5f)
                val b = PointF(r[1] + 0.5f, y + 0.5f)
                out.add(if (rowIdx % 2 == 0) listOf(a, b) else listOf(b, a))
            }
            rowIdx++
            y += gap
        }
        return out
    }

    // Zhang-Suen thinning
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val del = IntArray(w * h)
        var changed = true
        while (changed) {
            changed = false
            for (step in 0..1) {
                var cnt = 0
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        var n = 0
                        if (p2) n++
                        if (p3) n++
                        if (p4) n++
                        if (p5) n++
                        if (p6) n++
                        if (p7) n++
                        if (p8) n++
                        if (p9) n++
                        if (n < 2 || n > 6) continue
                        var a = 0
                        if (!p2 && p3) a++
                        if (!p3 && p4) a++
                        if (!p4 && p5) a++
                        if (!p5 && p6) a++
                        if (!p6 && p7) a++
                        if (!p7 && p8) a++
                        if (!p8 && p9) a++
                        if (!p9 && p2) a++
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        del[cnt++] = i
                    }
                }
                if (cnt > 0) {
                    changed = true
                    for (k in 0 until cnt) img[del[k]] = false
                }
            }
        }
    }

    private val dxs = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val dys = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)

    private fun trace(sk: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<List<PointF>>()
        val step = 2
        val minPts = 12

        fun neighborCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var n = 0
            for (k in 0 until 8) {
                val nx = x + dxs[k]
                val ny = y + dys[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                if (sk[ny * w + nx]) n++
            }
            return n
        }

        fun walk(start: Int) {
            val pts = ArrayList<Int>()
            var cur = start
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni] && !visited[ni]) { next = ni; break }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < minPts) return
            val res = ArrayList<PointF>()
            var k = 0
            while (k < pts.size) {
                res.add(PointF(pts[k] % w + 0.5f, pts[k] / w + 0.5f))
                k += step
            }
            if ((pts.size - 1) % step != 0) {
                val l = pts[pts.size - 1]
                res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            }
            if (res.size >= 2) out.add(res)
        }

        for (i in sk.indices) if (sk[i] && !visited[i] && neighborCount(i) <= 1) walk(i)
        for (i in sk.indices) if (sk[i] && !visited[i]) walk(i)
        return out
    }
}
