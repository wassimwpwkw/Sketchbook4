package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var bitmap: Bitmap? = null
    private var threshold = 90
    private var detail = 85
    private var fillGap = 6
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density

        val info = TextView(this).apply {
            text = "1) فعّل الخدمة\n2) اختر الصورة\n3) افتح Sketchbook وكانفس فارغ\n" +
                "4) اضغط ⛶ الكانفس في الشريط العائم وحدد زاويتي الكانفس\n5) اضغط ▶ ابدأ"
            textSize = 15f
            gravity = Gravity.CENTER
        }
        val btnAcc = Button(this).apply { text = "تفعيل الخدمة" }
        val btnPick = Button(this).apply { text = "اختيار صورة" }

        thLabel = TextView(this).apply { text = "سواد الخطوط: $threshold"; gravity = Gravity.CENTER }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        dtLabel = TextView(this).apply { text = "التفاصيل: $detail"; gravity = Gravity.CENTER }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        fgLabel = TextView(this).apply { text = "تباعد تعبئة العيون: $fillGap"; gravity = Gravity.CENTER }
        val seekFg = SeekBar(this).apply { max = 13; progress = fillGap - 3 }

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        status = TextView(this).apply { text = "لم تُختر صورة بعد"; gravity = Gravity.CENTER }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (24 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
            addView(info)
            addView(btnAcc)
            addView(btnPick)
            addView(thLabel)
            addView(seekTh)
            addView(dtLabel)
            addView(seekDt)
            addView(fgLabel)
            addView(seekFg)
            addView(preview, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (360 * d).toInt()))
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "اختر صورة"), 1)
        }
        seekTh.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                threshold = 20 + p
                thLabel.text = "سواد الخطوط: $threshold"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })
        seekDt.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                detail = p
                dtLabel.text = "التفاصيل: $detail"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })

        seekFg.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                fillGap = 3 + p
                fgLabel.text = "تباعد تعبئة العيون: $fillGap"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "جاري تحميل الصورة..."
            thread {
                val bmp = Tracer.load(this, uri, 1100)
                runOnUiThread {
                    if (bmp == null) {
                        status.text = "تعذّر فتح الصورة"
                    } else {
                        bitmap = bmp
                        process()
                    }
                }
            }
        }
    }

    private fun process() {
        val bmp = bitmap ?: return
        status.text = "جاري تحليل الصورة..."
        val t = threshold
        val dt = detail
        val fg = fillGap
        thread {
            val r = Tracer.process(bmp, t, dt, fg)
            runOnUiThread {
                Shared.strokes = r.strokes
                Shared.imgW = r.w
                Shared.imgH = r.h
                preview.setImageBitmap(r.preview)
                status.text = "جاهز: ${r.strokes.size} خط. افتح Sketchbook الآن."
            }
        }
    }
}
