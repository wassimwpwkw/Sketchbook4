package com.sketchbot.app

import android.graphics.PointF

object Shared {
    @Volatile var strokes: List<List<PointF>> = emptyList()
    @Volatile var imgW: Int = 1
    @Volatile var imgH: Int = 1
}
